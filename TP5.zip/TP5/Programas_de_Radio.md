# Programas de Radio 

## Dependencias funcionales (DFs):
1. `radio, año -> frecuencia_radio`
2. `radio, año -> gerente`
3. `radio, año, programa -> conductor`

## Claves candidatas:
La clave candidata es:  
**`radio, año, programa`**

Esta clave identifica de manera única cada registro, ya que une la radio, el año y el programa específico.

## Diseño normalizado (3FN):
El diseño normalizado divide la información en cuatro tablas para evitar redundancia y asegurar consistencia:

### Tabla: Radio
- **Atributos:** `radio_id (PK)`, `nombre_radio`
- **Descripción:** Contiene información sobre de cada radio.

### Tabla: Programa
- **Atributos:** `programa_id (PK)`, `nombre_programa`
- **Descripción:** Contiene información sobre cada programa de radio.

### Tabla: Gerente
- **Atributos:** `gerente_id (PK)`, `nombre_gerente`
- **Descripción:** Registra información sobre los gerentes, evitando duplicación.

### Tabla: Transmision
- **Atributos:** `transmision_id (PK)`, `radio_id (FK)`, `programa_id (FK)`, `gerente_id (FK)`, `año`, `frecuencia_radio`, `conductor`
- **Descripción:** Representa cada transmisión con sus detalles específicos (frecuencia, conductor, gerente asociado).

## Justificación del diseño:
1. **Evita redundancia:** Las tablas `Gerente`, `Programa` y `Radio` contienen datos únicos que se reutilizan en `Transmision`.
2. **Flexibilidad:** Es posible agregar más información a cada entidad (`Gerente`, `Programa`, `Radio`) sin afectar otras tablas.
3. **Cumple con la 3FN:** Cada atributo no clave depende completamente de la clave primaria de su tabla y no existen dependencias transitivas.